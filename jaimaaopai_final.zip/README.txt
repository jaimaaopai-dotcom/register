
ไฟล์นี้เป็นชุดไฟล์สำหรับอัปโหลดไปยัง GitHub Pages (username: jaimaaopai)
ไฟล์สำคัญ: index.html

วิธีติดตั้งผ่านเว็บ (ไม่ต้องใช้ Git):
1. เข้าไปที่ repo เปล่าของคุณ: https://github.com/jaimaaopai/jaimaaopai.github.io
2. กด 'Add file' -> 'Upload files'
3. เลือกไฟล์ index.html จาก ZIP (หรือแตกไฟล์แล้วอัปโหลด index.html)
4. Commit changes
5. รอ 1-2 นาที แล้วเปิด: https://jaimaaopai.github.io

ถ้าต้องการให้ผมช่วยแก้ข้อความ รูปภาพ หรือเพิ่มสินค้าเพิ่มเติม แจ้งได้เลยครับ
